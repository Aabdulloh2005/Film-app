import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:homework/widgets/image_container.dart';

class TabBarExample extends StatelessWidget {
  const TabBarExample({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double s_width = MediaQuery.of(context).size.width - 40;
    double s_height = MediaQuery.of(context).size.height - 40;
    return DefaultTabController(
      initialIndex: 1,
      length: 3,
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              const TabBar(
                dividerColor: Color(0xff565656),
                dividerHeight: 2,
                indicatorColor: Color(0xff820FE1),
                tabs: <Widget>[
                  Tab(
                    child: Text(
                      "Trailers",
                      style: TextStyle(color: Color(0xff820FE1), fontSize: 18),
                    ),
                  ),
                  Tab(
                    child: Text(
                      "More Like This",
                      style: TextStyle(color: Color(0xff820FE1), fontSize: 17),
                    ),
                  ),
                  Tab(
                    child: Text(
                      "Comments",
                      style: TextStyle(color: Color(0xff820FE1), fontSize: 18),
                    ),
                  ),
                ],
              ),
              Expanded(
                child: TabBarView(
                  children: <Widget>[
                    Center(
                        child: Column(
                      children: [ScrollingImage(s_height, s_width)],
                    )),
                    Center(
                      child: Column(
                        children: [ScrollingImage(s_height, s_width)],
                      ),
                    ),
                    Center(
                      child: Text("It's sunny here"),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
